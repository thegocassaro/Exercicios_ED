#include "forward_list.h"
#include <stdio.h>
#include <stdlib.h>


ForwardList *forward_list_construct(){
    
    ForwardList* l = (ForwardList*)calloc(1, sizeof(ForwardList));
    l->size = 0;
    l->head = NULL;

    return l;
}

int forward_list_size(ForwardList *l){
    
    return l->size;
}

void forward_list_push_front(ForwardList *l, data_type data){
    
    Node* node = node_construct(data, l->head);
    l->head = node;
    l->size++;
}

void forward_list_print(ForwardList *l, void (*print_fn)(data_type)){

    Node* n = l->head;
    printf("[");

    while(n != NULL){
        
        print_fn(node_value(n));
        n = node_next(n);

        if(n != NULL){
            printf(", ");
        }
    }
    
    printf("]");
}


void forward_list_destroy(ForwardList *l){
    
    Node* n = l->head;

    while(n != NULL){
        
        Node* next = node_next(n);
        node_destroy(n);
        n = next;
    }

    free(l);
}
