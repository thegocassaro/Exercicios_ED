#include <stdio.h>
#include "priority_queue_vector.h"
#include "vector.h"
#include "processos.h"
#include "heap.h"

int main(){

    int n=0;
    char nome[32], categoria[32]; 
    int identificador, prioridade;

    Heap* heap = heap_constructor(cmp_prio);

    scanf(" %d", &n);

    for(int i=0; i<n; i++){

        scanf(" %s %s %d %d", nome, categoria, &identificador, &prioridade);
        heap_push(heap, process_construct(nome, categoria, identificador, prioridade), prioridade);
    }

    for(int i=0; i<n; i++)
        process_print(heap->nodes[i].data);

    heap_destroy(heap);

    return 0;
}